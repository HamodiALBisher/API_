const { getUserByUsernameAndPassword, getUsersFromDB } = require('./Users.db');

async function checkUserCredentials(req, res) {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send({ error: 'Username and password are required' });
  }

  try {
    const user = await getUserByUsernameAndPassword(username, password);
    if (user) {
      res.status(200).send({ message: 'User authenticated successfully', user });
    } else {
      res.status(401).send({ error: 'Invalid username or password' });
    }
  } catch (error) {
    console.error('Error checking user credentials:', error);  // Log the error
    res.status(500).send({ error: 'Internal server error' });
  }
}

async function listAllUsers(req, res) {
  try {
    const users = await getUsersFromDB();
    res.status(200).send(users);
  } catch (error) {
    console.error('Error listing all users:', error);  // Log the error
    res.status(500).send({ error: 'Internal server error' });
  }
}

module.exports = { checkUserCredentials, listAllUsers };
