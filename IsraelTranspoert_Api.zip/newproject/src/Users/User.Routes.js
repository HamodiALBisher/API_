const express = require('express');
const { checkUserCredentials, listAllUsers } = require('./Users.Controller');
const router = express.Router();

router.post('/login', checkUserCredentials);
router.get('/', listAllUsers); // New route to list all users

module.exports = router;
